
package Conexao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Cliente;
import view.Cadastro;

public class ClienteConecta {
    private final Connection connection;

    public ClienteConecta(Connection connection) {
        this.connection = connection;
    }
    
    public void insert(Cliente cliente) throws SQLException{
        
            
            String sql = ("insert into cliente(nome, cpf, tipo) values ('"+cliente.getNome()+"', '"+cliente.getCpf()+"', '"+cliente.getPlano()+"');");
            
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.execute();       
            connection.close(); 
         
    }
    
}
